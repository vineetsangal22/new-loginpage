import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoginDataService } from '../services/login-data.service';


@Component({
  selector: 'app-registered-page',
  templateUrl: './registered-page.component.html',
  styleUrls: ['./registered-page.component.css']
})
export class RegisteredPageComponent {
  constructor(private snack:MatSnackBar, private login:LoginDataService ){}
  
  
 public user={
   fullname:'',
    email:'',
    mobile:'',
    password:'',
    

  };
  formSubmit(){
    console.log(this.user);
    if(this.user.fullname==''|| this.user.fullname==null){
      this.snack.open("First name is required !!", "ok");
     return;
    }
   
    this.login.addUser(this.user).subscribe((data:any)=>{
      console.log(data);
    })
    
    
  }
  

}
  



