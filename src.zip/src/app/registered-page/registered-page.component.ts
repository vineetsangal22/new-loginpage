import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-registered-page',
  templateUrl: './registered-page.component.html',
  styleUrls: ['./registered-page.component.css']
})
export class RegisteredPageComponent {
  constructor(private snack:MatSnackBar){}
  
 public user={
    firstName:'',
    lastName:'',
    DOB:'',
    Email:'',
    password:'',
    

  };
  formSubmit(){
    console.log(this.user);
    if(this.user.firstName==''|| this.user.firstName==null){
      this.snack.open("First name is required !!", "ok");
      return;
    }
    
      
  
    
  }


}
